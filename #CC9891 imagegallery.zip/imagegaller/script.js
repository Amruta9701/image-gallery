// Image Data
const images = [
    
    { src: 'images/animal1.jpeg', category: 'animals' },
    { src: 'images/animal2.jpg', category: 'animals' },
    { src: 'images/nature1.jpeg', category: 'nature' },
    { src: 'images/nature2.jpg', category: 'nature' },
    
    { src: 'images/nature3.jpg', category: 'nature' },
    { src: 'images/nature4.jpg', category: 'nature' },
    { src: 'images/travel3.jpg', category: 'travel' },
    { src: 'images/travel4.jpg', category: 'travel' },

    { src: 'images/travel5.jpg', category: 'travel' },
    { src: 'images/travel6.jpg', category: 'travel' }
];

// Function to display images
function displayImages(filteredImages) {
    const gallery = document.getElementById('gallery');
    gallery.innerHTML = ''; // Clear previous images

    filteredImages.forEach(image => {
        const imgElement = document.createElement('div');
        imgElement.classList.add('image-item');
        imgElement.innerHTML = `<img src="${image.src}" alt="${image.category}">`;
        gallery.appendChild(imgElement);
    });
}

// Function to filter images
function filterImages(category) {
    if (category === 'all') {
        displayImages(images);
    } else {
        const filtered = images.filter(img => img.category === category);
        displayImages(filtered);
    }
}

// Display all images on page load
window.onload = () => displayImages(images);
